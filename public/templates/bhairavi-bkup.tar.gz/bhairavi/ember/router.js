this.route('home', { 'path': '/' });
this.route('error', { 'path': '*path' });
