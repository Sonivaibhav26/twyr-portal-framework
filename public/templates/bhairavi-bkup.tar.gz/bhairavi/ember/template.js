<script type="text/x-handlebars" data-template-name="home">
<div class="box">
	<div class="box-body" style="padding:100px; text-align:center; font-size: 36px;">
		Home of the Twy'r Portal Framework
	</div>
</div>
</script>

<script type="text/x-handlebars" data-template-name="error">
<div class="box">
	<div class="box-body" style="padding:100px; text-align:center; font-size: 36px;">
		OOPS! Something happened!!
	</div>
</div>
</script>

