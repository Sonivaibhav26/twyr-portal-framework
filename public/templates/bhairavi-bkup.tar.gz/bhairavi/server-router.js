/// <reference path="../../../typings/node/node.d.ts"/>
/*
 * Name			: framework-router.js
 * Author		: Vish Desai (vishwakarma_d@hotmail.com)
 * Version		: 0.5.1
 * Copyright	: Copyright (c) 2014 Vish Desai (https://www.linkedin.com/in/vishdesai).
 * License		: The MIT License (http://opensource.org/licenses/MIT).
 * Description	: The Twy'r Portal Router
 *
 */

"use strict";

/**
 * Module dependencies.
 */
var path = require('path');

var frameworkRouter = (function() {
	// Step 1: Instantiate the Router itself...
	var router = require('express').Router(),
		logger = require('morgan'),
		loggerSrvc = this.$services.logger.getInterface(),
		self = this;

	// Step 2: Setup the logger for the router...
	var loggerStream = {
		'write': function(message, encoding) {
			loggerSrvc.silly(message);
		}
	};

	router.use(logger('combined', {
		'stream': loggerStream
	}));
	
	// Step 3: Process all unhandled ('/') paths by returning the application template
	router.all('/*', function(request, response, next) {
		loggerSrvc.silly('Framework Router Rendering: ', request.path, ' with:\nQuery: ', request.query, '\nBody: ', request.body, '\nParams: ', request.params);

		var renderOptions = {
			'title': self.$config.title,
			'baseYear': self.$config.baseYear,
			'currentYear': (new Date()).getFullYear().toString(),

			'template': path.relative(self.$config.publicDir, path.join(self.$config.templates.path, self.$config.currentTemplate.name)),
			'clientLoader': path.relative(self.$config.publicDir, path.join(self.$config.templates.path, self.$config.currentTemplate.name, self.$config.currentTemplate.client_loader)),
			'authenticated': !!request.user,

			'developmentMode': ((process.env.NODE_ENV || 'development') == 'development'),
			'apiServer': self.$config.apiServer,

			'userId': request.user ? request.user.id : null,
			'userName': request.user ? (request.user.first_name + ' ' + request.user.last_name) : '',

			'permissions': request.user ? (request.user.permissions || []) : [],
			'settingsMenu': request.user ? (request.user.settingsRoutes || []) : [],
			'menu': request.user ? (request.user.emberRoutes || []) : [],

			'components': []
		};

		var mountPath = self.$config ? (self.$config.componentMountPath || '') : '';
		for(var idx in self.$components) {
			renderOptions.components.push({ 'name': path.join(mountPath, idx) });
		}

		loggerSrvc.debug('Framework Router Render Options: ', renderOptions);
		response.render(path.join(self.$config.templates.path, self.$config.currentTemplate.name, self.$config.currentTemplate.client_index_file), renderOptions, function(err, html) {
			if(err) {
				loggerSrvc.error('Framework Router Render Error: ', request.path, ' with:\nQuery: ', request.query, '\nBody: ', request.body, '\nParams: ', request.params, '\nError: ', err, '\nHTML: ', html);
				response.status(err.code || err.number || 404).redirect('/error');
				return;
			}
			
			loggerSrvc.silly('Framework Router Render Result: ', request.path, ' with:\nQuery: ', request.query, '\nBody: ', request.body, '\nParams: ', request.params, '\nHTML: ', html);
			response.status(200).send(html);
		});
	});

	return router;
});

exports.router = frameworkRouter;
