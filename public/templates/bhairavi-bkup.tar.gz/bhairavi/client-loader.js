/*
 * Name			: public/templates/default/js/framework-loader.js
 * Author		: Vish Desai (vishwakarma_d@hotmail.com)
 * Version		: 0.5.1
 * Copyright	: Copyright (c) 2014 Vish Desai (https://www.linkedin.com/in/vishdesai).
 * License		: The MIT License (http://opensource.org/licenses/MIT).
 * Description	: The Twy'r Portal client application loader / initializer
 *
 */

"use strict";

window.emberTemplates = [];
window.emberMVCs = [];
window.emberRoutes = '';

console.log('Loading Ember Handlebars Templates:\n', window.templates);
window.curl(window.templates).then(function() {
	if(arguments.length) {
		var numTmpl = arguments.length;
		for(var tmplIdx = 0; tmplIdx < numTmpl; tmplIdx++) {
			var thisTemplate = arguments[tmplIdx];
			window.emberTemplates.push(thisTemplate);
		}
	}

	console.log('Loading Ember MVC scripts:\n', window.mvcs);
	window.curl(window.mvcs).then(function() {
		if(arguments.length) {
			var numMVCs = arguments.length;
			for(var mvcIdx = 0; mvcIdx < numMVCs; mvcIdx++) {
				var thisMVC = arguments[mvcIdx];
				window.emberMVCs.push(thisMVC);
			}
		}

		console.log('Loading Ember Routes:\n', window.routes);
		window.curl(window.routes).then(function() {
			// Step 1: Form the function to load the Ember Routes
			if(arguments.length) {
				var numRoutes = arguments.length;
				for(var routeIdx = 0; routeIdx < numRoutes; routeIdx++) {
					window.emberRoutes += arguments[routeIdx] + '\n';
				}

				window.emberRoutes = new Function([], window.emberRoutes);
			}

			// Step 2: Load all the templates
			console.log('Adding template scripts to the document');
			for(var tmplIdx = 0; tmplIdx < window.emberTemplates.length; tmplIdx++) {
				var thisTemplate = window.emberTemplates[tmplIdx];
				$('head').append(thisTemplate);
			}
	
			// Step 3: Define the client-side EmberJS-based application
			console.log('Starting the Ember Application');
			window.Portal = window.Ember.Application.create({
				LOG_RESOLVER: window.developmentMode,
				LOG_ACTIVE_GENERATION: window.developmentMode, 
				LOG_TRANSITIONS: window.developmentMode, 
				LOG_TRANSITIONS_INTERNAL: window.developmentMode,
				LOG_VIEW_LOOKUPS: window.developmentMode
			});

			// Step 4: Setup the Adapters
			window.Portal.ApplicationAdapter = window.DS.RESTAdapter.extend({
				'namespace': '',
				'host': window.apiServer.substring(0, window.apiServer.length - 1),

				'ajaxError': function(jqXHR) {
					if (jqXHR && jqXHR.status == 422) {
						var jsonErrors = window.Ember.$.parseJSON(jqXHR.responseText)["errors"];
						return new window.DS.InvalidError(jsonErrors);
					}
					else {
						var error = this._super(jqXHR);
						return error;
					}
				}
			});

			// Step 5: Random Ember configurations...
			window.Portal.Router.reopen({
				'location': 'history'
			});

			// Step 6: Load all the Ember MVC stuff
			console.log('Adding Ember MVCs to the document');
			for(var mvcIdx = 0; mvcIdx < window.emberMVCs.length; mvcIdx++) {
				var thisMVC = window.emberMVCs[mvcIdx];
				$('head').append(thisMVC);
			}

			// Step 7: Create the Ember Router map...
			console.log('Creating Ember Routes');
			window.Portal.Router.map(window.emberRoutes);

			// Step 8: If authenticated, add the logout route, etc.
			if(window.authenticated) {
				window.Portal.ApplicationController = window.Ember.ObjectController.extend({
					'actions': {
						'toggleMenu': function() {
							var action = $('li#li-user-menu').hasClass('open') ? 'removeClass' : 'addClass';
							($('li#li-user-menu')[action])('open');
						},

						'doLogout': function() {
							$.ajax({
								'type': 'GET',
								'url': window.apiServer + 'login/doLogout',

								'success': function(data) {
									if(data.status) {
										window.location.href = '/';
									}
								}
							});
						}
					}
				});
			}

			// Finally, cleanup...
			delete window.emberTemplates;
			delete window.emberMVCs;
			delete window.emberRoutes;

			delete window.templates;
			delete window.mvcs;
			delete window.routes;
		});
	});
});

